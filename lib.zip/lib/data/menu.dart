import 'package:flutter/cupertino.dart';

class Menu {
  late String title;

  late IconData icon;

  late Color warna;
}